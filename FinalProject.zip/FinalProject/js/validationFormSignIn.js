document.getElementById('submitBtn').addEventListener('click', function() {
    const emailInput = document.getElementById('loginEmail');
    const passwordInput = document.getElementById('loginPswInput');
    const userData = JSON.parse(localStorage.getItem('user'));

    emailInput.classList.remove('is-invalid');
    passwordInput.classList.remove('is-invalid');

    if (!emailInput.value) {
        emailInput.classList.add('is-invalid');
        return;
    }
    if (!passwordInput.value) {
        passwordInput.classList.add('is-invalid');
        return;
    }

    if (!userData) {
    Swal.fire({
        title: 'Usuario no encontrado!',
        text: 'Por favor, regístrate primero.',
        icon: 'error',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2000
    });
    }   else if (userData.email === emailInput.value && userData.password === passwordInput.value) {
    window.location.href = 'index.html';
    }   else {
    Swal.fire({
        title: 'Credenciales incorrectas!',
        text: 'Por favor, intenta de nuevo.',
        icon: 'error',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2000
    });
}
});
