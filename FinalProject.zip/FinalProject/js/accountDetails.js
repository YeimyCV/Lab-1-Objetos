window.addEventListener('DOMContentLoaded', () => {
    const userData = JSON.parse(localStorage.getItem('user'));
    const fullNameElement = document.getElementById('fullName');
    const emailElement = document.getElementById('email');

    if (userData) {
        const { name, surname, email } = userData;

        if (name && surname) {
            fullNameElement.textContent = `${name} ${surname}`;
        } else {
            fullNameElement.textContent = '';
        }

        if (email) {
            emailElement.textContent = email;
            emailElement.href = `mailto:${email}`;
        } else {
            emailElement.textContent = '';
            emailElement.href = '';
        }
    } else {
        fullNameElement.textContent = '';
        emailElement.textContent = '';
        emailElement.href = '';
    }
});
