//Boton que redirige
const showButton = document.getElementById('Show');
showButton.addEventListener('click', function(event) {
    event.preventDefault();
    window.location.href = 'AllContacts.html';
});
//Boton que redirige termina aqui

