//Boton que redirige
const backButton = document.getElementById('backButton');
backButton.addEventListener('click', function(event) {
    event.preventDefault();
    window.location.href = 'AddContacts.html';
});
//Boton que redirige termina aqui

